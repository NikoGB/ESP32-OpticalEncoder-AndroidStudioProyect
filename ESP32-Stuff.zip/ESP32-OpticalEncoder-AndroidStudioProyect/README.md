# ESP32-OpticalEncoder-AndroidStudioProyect
