package com.example.finalencoder_controller;

public class SettingsFragment {
}
